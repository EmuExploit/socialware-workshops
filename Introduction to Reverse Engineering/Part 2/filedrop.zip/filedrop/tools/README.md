# Instructions

Download `Binary Ninja` from [here](https://binary.ninja/demo/).

Note: For compiling excersises with `make` as per instructions, you may need to refer to the [install script](https://github.com/EmuExploit/socialware-workshops/blob/main/Introduction%20to%20Reverse%20Engineering/Part%201/filedrop/tools/install.sh) from Part 1 of the workshop.
