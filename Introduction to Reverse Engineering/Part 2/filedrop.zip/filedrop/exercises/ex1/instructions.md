# Exercise 1 Instructions

- Fix the file, it should print the next number in the fibonacci sequence `n` times
- Compile the program by running `make`
- If something screws up, run `make clean` to start again from the source file
