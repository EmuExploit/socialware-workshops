// FIX ME!!


int fibonacci(unsigned int n) {
	int prev = 0;
	int curr = 1;
	int tmp  = 0;

	for (int i = 0; i < n; i ++) {
		tmp = curr // FIX ME!!
		curr = curr + prev;
		prev = tmp;

		printf("", curr); // FIX ME!!
	}

	return curr;
}

int main(void) {
	// FIX ME!!
	return 0;
}
