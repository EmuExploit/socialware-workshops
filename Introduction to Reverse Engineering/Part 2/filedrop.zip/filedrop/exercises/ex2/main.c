#include <stdio.h>
#include <string.h>

void encrypt(char* s, /* FIX ME*/) {
	for (int i = 0; /*FIX ME!! */; i ++) {
		s[i] += key;
	}
}


int main(void) {
	char plaintext[] = "EMUEXPLOIT";
	
	encrypt(plaintext,13);
	//FIX ME!!
}
