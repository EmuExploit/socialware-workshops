# Exercise 1 Instructions

- Fix the file, it should implement an "ascii shift" cipher. Currently we specify a key of 13.
- Compile the program by running `make`
- If something screws up, run `make clean` to start again from the source file
