# Exercise 1 Instructions

- Find the flag :)
